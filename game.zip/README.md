# [nage](https://github.com/acikek/nage-rs) Example Game

This is an example **Nagame** fitted with all the latest features for demonstration purposes. If you've never made a Nagame before, clone this repository and take a look through the files!